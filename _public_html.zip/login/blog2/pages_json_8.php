 
 <h1 title="<?php echo   $liste_projet_description1_tittle_x1_7[$x1_7] ; ?>"  id="<?php echo   "id_".$liste_projet_id_sha1_x1_7[$x1_7] ; ?>" >
      <?php echo $liste_projet_name_x1_7[$x1_7] ; ?>
 </h1>

 <p title="<?php echo   $liste_projet_description1_tittle_x1_7[$x1_7] ; ?>"  id="<?php echo   "id_p_".$liste_projet_id_sha1_x1_7[$x1_7] ; ?>"  >
<?php 

echo $liste_projet_description1_x1_7[$x1_7] ;
?>
 </p>


 <?php 



$img ="../../redirection_dowload_img/".$liste_projet_img_x1_7[$x1_7] ; 
if($liste_projet_img_x1_7[$x1_7]!=""){

 
  ?>
  <img src="<?php echo $img  ; ?> " alt="Paris" width="<?php $width."%" ?>" style="margin:70px;text-center"> 
  <?php 
}

/*

echo $liste_projet_id_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_id_sha1_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_id_parent_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_id_sha1_general_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_ip_x1_7[$x1_7] ;
echo "<br/>" ; 



echo $liste_projet_img_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_name_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_description1_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_description2_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_visibilite1_x1_7[$x1_7] ;
echo "<br/>" ; 



echo $liste_projet_visibilite2_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_type_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $information_user_id_sha1_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_new_file_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_reg_date_x1_7[$x1_7] ;
echo "<br/>" ; 



echo $liste_projet_color_1_x1_7[$x1_7] ;
echo "<br/>" ; 


echo $liste_projet_color_2_x1_7[$x1_7] ;
echo "<br/>" ; 



echo $liste_projet_name_font_size_x1_7[$x1_7] ;
echo "<br/>" ; 

echo $liste_projet_description1_font_size_x1_7[$x1_7] ;
echo "<br/>" ; 


echo $liste_projet_background_color_x1_7[$x1_7] ;
echo "<br/>" ; 


 */









?>
  