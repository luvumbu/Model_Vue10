 



<div class="general__">
 
          <div class="element_1">    
                <div class="mon_img"></div>
                    <h2>Titre 1 </h2>
                      <p>
                      Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                      Numquam quisquam doloribus quaerat? Dignissimos, sint, commodi 
                      rerum animi recusandae aut a beatae cumque deleniti veritatis ex cum? Voluptate adipisci velit amet?
                      </p> 

                      <div class="alert alert-secondary" role="alert"> Voir l'article  </div>    
          </div>

</div>






<style>

  .general__{
 
    display:flex ; 
    justify-content:space-around ; 
    width:80%; 
    margin:auto  ;   
      flex-wrap:wrap ;  
  }
  .element_1{
    width:300px; 

    border-radius:15px  ; 
    text-align:center ; 
 

    margin : 10px; 
  }
  .element_1 h2{
 
    text-align:center ; 
  }
  .element_1 p{
 
 text-align:justify ; 
}
.mon_img{
  width:100% ; 
 
  height:100px;
    border-radius:15px  15px 0 0  ; 
    background-image:url("https://bokonzi.com/login/redirection_dowload_img/uploads/ef369c1fed3c5c370c0c2ea8e6f0c6daf217a924/1700730359509.png") ; 
background-size:100% ; 
 
}


@font-face {
  font-family: Prassent Geek;
  src: url(Prassent Geek.ttf);
}
body{
  font-family: Prassent Geek;

}
</style>