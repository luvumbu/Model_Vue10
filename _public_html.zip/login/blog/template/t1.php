<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>






<img src="logo.png" alt="" srcset="">




<div>Home</div>
<div>Services</div>
<div>About</div>
<div>Clients</div>
<div>News</div>
<div>Portfolio</div>
<div>Pricing</div>
<div>Team</div>
<div>Skills</div>
<div>Milestones</div>
<div>Contact</div>

</body>
</html>