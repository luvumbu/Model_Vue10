  <style>
  .parent{
    background-color:rgba(0,0,0,0.4) ; 
  }
  .x0 {
    background-color:rgba(0,100,0,0.4) ; 

  }
 </style>