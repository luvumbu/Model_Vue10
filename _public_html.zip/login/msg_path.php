<div class="container-fluid p-5 bg-primary text-white text-center">
    <h1>Bonjour </h1>

</div>

<div class="container mt-5">

    <h1>
        Bienvenue sur BOKONZI !
    </h1>
    <p>
        Cher client privilégié ,
    </p>

    <p>
        C'est avec une grande joie que nous vous accueillons sur notre plateforme en ligne. 🌟 Nous sommes
        reconnaissants de votre intérêt pour nos projets et services.

        Préparez-vous à plonger dans l'univers captivant de BOKONZI. Chacun de nos projets est le fruit d'un dévouement
        total et d'une passion sans limite. Nous sommes ravis de pouvoir partager cela avec vous.

    </p>
    <p>
        Votre soutien est notre moteur, et nous sommes impatients de vous offrir une expérience mémorable.
    </p>

    <p>
        Merci de faire partie de notre histoire !

    </p>
    <p>
        Bien à vous,
    </p>
    L'équipe de BOKONZI


    <h1 id="nombre"></h1>
</div>
<script>
    var nombre = 20;
    const element = document.getElementById("demo");
    setInterval(function () {
        document.getElementById("nombre").innerHTML = "Redirection vers projet dans " + nombre;
        nombre--
    }, 1000);
</script>