 <?php 
include("../blog/index.php") ; 

?>