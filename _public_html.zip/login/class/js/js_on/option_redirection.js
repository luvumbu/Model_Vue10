function option_redirection1(_this){
         window.location.replace("../vlog.php/"+_this.title);

}
 