function voir_projet_2(_this) {
	
 
	const d = new Date();
 time = d.getTime();
 

console.log(time) ;
 document.cookie = "username="+recherche_elements(_this," ");

 location.reload() ; 
 
 }
