function id_input_update_all(_this,array_recherche){
	 
	return document.getElementsByClassName(_this)[array_recherche].value ; 
}