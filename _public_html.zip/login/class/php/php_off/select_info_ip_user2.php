<?php 
session_start() ; 
header("Access-Control-Allow-Origin: *");
include("link.php") ; 


 
?>