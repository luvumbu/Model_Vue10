<?php 
 



$filename_1="../../../../model/class/php/connexion.php";

$filename_2="../../../../model/class/php/Insertion_Bdd.php";/*
$filename_3="../../../../model/class/php/Select_datas.php";

 
 
 
    include($filename_1) ; 
 
    include($filename_3) ; 

    */
  
?> 