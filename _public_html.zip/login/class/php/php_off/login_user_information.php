<?php
session_start(); 
 
include("link.php") ;  
echo  $_SESSION["status"]  ; 
 
 ?>
