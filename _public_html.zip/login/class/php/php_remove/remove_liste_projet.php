<?php 
session_start() ; 
header("Access-Control-Allow-Origin: *");
/*
//methode a changer totalement
      $apple = new Insertion_Bdd(
            $servername,
            $username,
            $password,
            $dbname
            
            );
            $apple->set_msg_valudation("remove ok ") ;  
            $apple->set_sql('DELETE FROM  `liste_projet_child` WHERE  `liste_projet_child_id_general` = "'.$liste_projet_cookie.'"') ; 
            $apple->execution() ;
       */
?>