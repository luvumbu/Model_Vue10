<?php 
session_start() ;  
echo  $_SESSION["add_liste_projet"] ; 
?>