<?php 
 

$emplacement ="../../../../" ; 
$filename_1=$emplacement."model/class/php/connexion.php";
$filename_2=$emplacement."model/class/php/Insertion_Bdd.php";
$filename_3=$emplacement."model/class/php/Select_datas.php";

$filename_4=$emplacement."model/class/php/config_folder_verif";
 
  
 
    include($filename_1) ; 
    include($filename_2) ;
    include($filename_3) ; 
 
 


?> 