
 <header>
    
    <?php        
        include("view/header.php");
    ?>
</header>
<section>
 
    <?php       
        include("view/section.php");
    ?>
</section>
<footer>
 
    <?php       
         include("view/footer.php");          
    ?>
</footer>


 