<?php

$dbname="u489596434_model_vue_8";
$username="u489596434_model_vue_8";
$password="v3p9r3e@59A";
$servername="localhost";

?>
