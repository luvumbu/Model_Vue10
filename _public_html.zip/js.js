const ip = document.getElementById("ip").title; 
envoyer_ip_serveur("model/class/php/envoyer_ip_serveur.php",ip) ;
 
